# -*- coding: utf-8 -*-
"""
film_scene.py — la partie « calcul » du rendu Blender de l'essai GPU (paquet 299), sans Blender : lecture du fichier
exporté par scripts/film_export.py, changement de repère, déformation des personnages par leurs os, panneaux du public,
caméra, et la règle des couleurs de tenue du moteur du site écrite une seule fois pour deux usages : calcul direct
(numpy, pour les tests) et nœuds de matériau Blender (scripts/blender_film.py).

Repère du site : y vers le haut (WebGL). Repère de Blender : z vers le haut. (x, y, z) du site → (x, −z, y).
"""
import base64
import gzip
import json
import math

import numpy as np

# site → Blender (rotation de +90° autour de x : déterminant +1, rien n'est retourné)
C3 = np.array([[1.0, 0.0, 0.0], [0.0, 0.0, -1.0], [0.0, 1.0, 0.0]])
C4 = np.eye(4)
C4[:3, :3] = C3

TYPES = {'p': np.float32, 'n': np.float32, 'c': np.float32, 'u': np.float32, 'w': np.float32, 'b': np.uint8,
         'cls': np.uint8, 'i': np.uint32}


def lire(chemin):
    with gzip.open(chemin, 'rt', encoding='utf-8') as f:
        return json.load(f)


def tableau(b64, type_np):
    return np.frombuffer(base64.b64decode(b64), dtype=type_np)


def maillage(film, mid):
    """Maillage exporté → dict de tableaux numpy (p : n×3, i : t×3, …) ; None s'il n'existe pas."""
    d = film['maillages'].get(str(mid))
    if not d:
        return None
    nv = d['nv']
    out = {'nv': nv}
    for k, t in TYPES.items():
        if k in d:
            a = tableau(d[k], t)
            dim = {'p': 3, 'n': 3, 'c': 3, 'u': 2, 'w': 4, 'b': 4, 'cls': 1, 'i': 3}[k]
            out[k] = a.reshape(-1, dim) if dim > 1 else a.copy()
    if 'inst' in d:
        out['inst'] = {'pos': tableau(d['inst']['pos'], np.float32).reshape(-1, 4),
                       'col': tableau(d['inst']['col'], np.float32).reshape(-1, 3)}
    return out


def mat4(liste):
    """Matrice du site (16 nombres, colonne par colonne) → numpy 4×4."""
    return np.asarray(liste, dtype=np.float64).reshape(4, 4).T


def os_image(film, k):
    """Les 24 matrices d'os (déjà placées dans le monde) d'une pose → 24×4×4."""
    a = tableau(film['os'][k], np.float32).astype(np.float64).reshape(24, 4, 4)
    return np.transpose(a, (0, 2, 1))


def deformer(p, b, w, S):
    """Peau du personnage : chaque sommet suit ses 4 os (poids normalisés), comme le shader du site."""
    w = w.astype(np.float64)
    w = w / np.maximum(w.sum(axis=1, keepdims=True), 1e-4)
    ph = np.concatenate([p.astype(np.float64), np.ones((len(p), 1))], axis=1)
    out = np.zeros((len(p), 3))
    for k in range(4):
        Sk = S[b[:, k].astype(np.int64)]                       # n×4×4
        out += w[:, k:k + 1] * np.einsum('nij,nj->ni', Sk, ph)[:, :3]
    return out


def deformer_normales(n, b, w, S):
    """Normales : seulement la rotation des os (pas leur déplacement), puis longueur 1."""
    R = S.copy()
    R[:, :3, 3] = 0.0
    N = deformer(n, b, w, R)
    return N / np.maximum(np.linalg.norm(N, axis=1, keepdims=True), 1e-9)


def vers_blender(p):
    """Points du site (n×3) → points de Blender."""
    return np.asarray(p, dtype=np.float64) @ C3.T


def lineaire(c):
    """Couleur du site (0–1, espace de l'écran) → couleur linéaire de Blender."""
    return np.power(np.clip(np.asarray(c, dtype=np.float64), 0, None), 2.2)


def camera(eye, cible):
    """Matrice monde de la caméra Blender (elle regarde vers son −z local, haut = +y local), dans le repère Blender."""
    e, c = vers_blender([eye])[0], vers_blender([cible])[0]
    f = c - e
    f /= np.linalg.norm(f)
    haut = np.array([0.0, 0.0, 1.0])
    x = np.cross(f, haut)
    if np.linalg.norm(x) < 1e-6:
        x = np.array([1.0, 0.0, 0.0])
    x /= np.linalg.norm(x)
    y = np.cross(x, f)
    M = np.eye(4)
    M[:3, 0], M[:3, 1], M[:3, 2], M[:3, 3] = x, y, -f, e
    return M


def projeter(Mcam, fov, aspect, points_blender):
    """Projection de points (repère Blender) par la caméra : coordonnées 0–1 de l'image (0,0 en haut à gauche)."""
    inv = np.linalg.inv(Mcam)
    q = np.c_[points_blender, np.ones(len(points_blender))] @ inv.T
    z = -q[:, 2]
    t = 1 / math.tan(fov / 2)
    x = q[:, 0] / z * t / aspect
    y = q[:, 1] / z * t
    return np.c_[(x + 1) / 2, (1 - y) / 2], z


def hache(x, z):
    """Même tirage que le shader (fract(sin(dot(xz, (12.9898, 78.233))) × 43758.5453)), en 32 bits."""
    x, z = np.float32(x), np.float32(z)
    v = np.sin(x * np.float32(12.9898) + z * np.float32(78.233)).astype(np.float32) * np.float32(43758.5453)
    return (v - np.floor(v)).astype(np.float64)


def public(base, inst, eye, t_reel, clap, debout):
    """Panneaux du public tournés vers la caméra, rebond des applaudissements, une partie debout (shader uInst == 2).
    base : maillage du panneau (p, u) ; inst : positions/échelles et couleurs. Renvoie (points n×3 du site, uv, couleurs
    par sommet)."""
    P, U = base['p'].astype(np.float64), base['u'].astype(np.float64)
    pos, col = inst['pos'].astype(np.float64), inst['col'].astype(np.float64)
    N = len(pos)
    dx, dz = eye[0] - pos[:, 0], eye[2] - pos[:, 2]
    a = np.arctan2(dx, dz)
    h = hache(pos[:, 0], pos[:, 2])
    leve = (h >= 0.55) * debout
    rebond = np.maximum(0, np.sin(t_reel * (3 + clap * 9) + pos[:, 0] * 1.7 + pos[:, 2])) * (0.04 + clap * 0.14)
    ca, sa = np.cos(a)[:, None], np.sin(a)[:, None]
    qx, qy, qz = ca * P[None, :, 0], np.broadcast_to(P[None, :, 1], (N, len(P))), -sa * P[None, :, 0]
    s = pos[:, 3:4]
    X = qx * s + pos[:, 0:1]
    Y = qy * s + pos[:, 1:2] + (leve * 0.32 + rebond)[:, None]
    Z = qz * s + pos[:, 2:3]
    pts = np.stack([X, Y, Z], axis=-1).reshape(-1, 3)
    cases = np.floor(h * 7.99)
    uv = np.stack([(U[None, :, 0] + cases[:, None]) / 8.0, np.broadcast_to(U[None, :, 1], (N, len(U)))], axis=-1).reshape(-1, 2)
    couleurs = np.repeat(col, len(P), axis=0)
    return pts, uv, couleurs


def indices_public(base, n_inst):
    I = base['i'].astype(np.int64)
    nv = len(base['p'])
    return (I[None, :, :] + (np.arange(n_inst) * nv)[:, None, None]).reshape(-1, 3)


# ── la règle des couleurs de tenue (shader du site, paquets 264 → 293), pour deux « moteurs » ─────────────────
class NP:
    """Moteur de calcul direct (numpy)."""
    def c(self, v): return float(v)
    def add(self, a, b): return a + b
    def sub(self, a, b): return a - b
    def mul(self, a, b): return a * b
    def gt(self, a, b): return (np.asarray(a) > b).astype(np.float64)
    def lt(self, a, b): return (np.asarray(a) < b).astype(np.float64)
    def abs(self, a): return np.abs(a)
    def max(self, a, b): return np.maximum(a, b)
    def floor(self, a): return np.floor(a)
    def sqrt(self, a): return np.sqrt(np.maximum(a, 0))
    def sel(self, c, a, b): return b + (a - b) * c


def ou(B, a, b): return B.max(a, b)
def et(B, a, b): return B.mul(a, b)
def non(B, a): return B.sub(B.c(1), a)
def egal(B, a, k): return non(B, B.gt(B.abs(B.sub(a, B.c(k))), B.c(0.5)))


def classe_tenue(B, x, y, z, cls, t0x, t0y):
    """k (0 = peau, 1 maillot, 2 côtés, 3 short, 4 liseré, 5 blanc, 6 semelle, 7 bandeau) d'un point de la pose de repos
    (x, y, z : repère du site) — même calcul que le fragment shader du site."""
    k = B.floor(B.add(cls, B.c(0.5)))
    # au-dessus du cou : peau ou bandeau seulement
    tete = et(B, B.gt(y, B.c(t0y - 0.08)), et(B, B.gt(k, B.c(0.5)), B.lt(k, B.c(6.5))))
    k = B.sel(tete, B.c(0), k)
    ax = B.abs(x)
    zc = B.add(z, B.c(0.03))
    rcou = B.sqrt(B.add(B.mul(x, x), B.mul(zc, zc)))
    torse = et(B, et(B, B.lt(ax, B.c(0.355)), B.gt(y, B.c(0.99))),
               ou(B, B.lt(y, B.c(1.43)), et(B, B.gt(rcou, B.c(0.088)), B.lt(y, B.c(1.56)))))
    zone = et(B, B.lt(k, B.c(2.5)), et(B, B.gt(y, B.c(0.99)), B.lt(y, B.c(1.75))))
    bord = ou(B, B.gt(ax, B.c(0.33)), et(B, et(B, B.lt(B.abs(B.add(z, B.c(0.02))), B.c(0.035)), B.gt(ax, B.c(0.125))), B.lt(y, B.c(1.4))))
    k_zone = B.sel(torse, B.sel(bord, B.c(2), B.c(1)), B.c(0))
    k = B.sel(zone, k_zone, k)
    short = ou(B, egal(B, k, 3), egal(B, k, 4))
    liser = ou(B, B.lt(y, B.c(t0x + 0.035)), et(B, et(B, B.gt(ax, B.c(0.15)), B.lt(B.abs(zc), B.c(0.028))), B.lt(y, B.c(1.0))))
    k = B.sel(short, B.sel(liser, B.c(4), B.c(3)), k)
    peau_band = ou(B, egal(B, k, 0), egal(B, k, 7))
    band = et(B, et(B, B.gt(y, B.c(t0y)), B.lt(y, B.c(t0y + 0.032))), et(B, B.lt(z, B.c(0.1)), B.gt(z, B.c(-0.14))))
    k = B.sel(peau_band, B.sel(band, B.c(7), B.c(0)), k)
    return k


def classe_reference(x, y, z, cls, t0x, t0y):
    """Le même calcul, recopié ligne à ligne du GLSL (pour vérifier classe_tenue)."""
    out = np.zeros(len(x), dtype=int)
    for i in range(len(x)):
        X, Y, Z = x[i], y[i], z[i]
        k = int(cls[i] + 0.5)
        if Y > t0y - 0.08 and 0 < k < 7:
            k = 0
        ax, rcou = abs(X), math.hypot(X, Z + 0.03)
        torse = ax < 0.355 and Y > 0.99 and (Y < 1.43 or (rcou > 0.088 and Y < 1.56))
        if k in (0, 1, 2) and 0.99 < Y < 1.75:
            k = 1 if torse else 0
            if k == 1 and (ax > 0.33 or (abs(Z + 0.02) < 0.035 and ax > 0.125 and Y < 1.4)):
                k = 2
        if k in (3, 4):
            k = 4 if (Y < t0x + 0.035 or (ax > 0.15 and abs(Z + 0.03) < 0.028 and Y < 1.0)) else 3
        if k in (0, 7):
            k = 7 if (t0y < Y < t0y + 0.032 and -0.14 < Z < 0.1) else 0
        out[i] = k
    return out


def duree_estimee(s_par_image, images_video=75 * 25, demarrage_s=180):
    """Temps de machine pour la partie 3D d'une vidéo entière (75 s à 25 images/s, démarrage compris), en heures."""
    return (s_par_image * images_video + demarrage_s) / 3600.0


def cout_mensuel(heures_par_video, videos_par_jour, prix_heure=0.94, jours=30):
    return heures_par_video * videos_par_jour * jours * prix_heure
