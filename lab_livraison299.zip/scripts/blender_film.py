#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
blender_film.py — ESSAI (paquet 299) : le point exporté du site (scripts/film_export.py) rendu par Blender (Cycles)
sur la carte graphique d'une machine louée (Modal, scripts/modal_rendu.py).

Mêmes maillages, mêmes textures, mêmes mouvements, même caméra que le site, image par image. Ce qui change :
- la lumière : projecteurs du stade (ou soleil et ciel le jour) avec ombres douces et lumière qui rebondit ;
- les matières : court dur ou moquette vernis (vrais reflets), tissu des tenues, peau, balle ;
- la caméra : vraie profondeur de champ sur les gros plans, flou de mouvement de la balle et des raquettes.
L'exposition est réglée une fois, sur la première image, par une petite image d'essai.

Lancement : blender -b --factory-startup -P scripts/blender_film.py -- --entree film.json.gz --sortie images
            [--echantillons 64] [--images tout|0,50,99] [--max-images 400] [--pourcent 100]
Sortie : images PNG (img_0000.png…) et temps.json (secondes par image, carte graphique utilisée).
"""
import base64
import json
import math
import os
import sys
import time

import bpy
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import film_scene as FS  # noqa: E402


def options():
    a = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
    o = {'entree': 'film.json.gz', 'sortie': 'images', 'echantillons': '64', 'images': 'tout', 'max-images': '400',
         'pourcent': '100', 'exposition': 'auto'}
    for k in range(0, len(a) - 1, 2):
        o[a[k].lstrip('-')] = a[k + 1]
    return o


def essai(f, *a, **k):
    try:
        return f(*a, **k)
    except Exception as e:                                            # un réglage absent de cette version : on passe
        print('  (réglage ignoré :', type(e).__name__, str(e)[:120], ')')
        return None


def entree(noeud, *noms):
    for n in noms:
        if n in noeud.inputs:
            return noeud.inputs[n]
    return None


def regler(noeud, valeur, *noms):
    s = entree(noeud, *noms)
    if s is not None:
        s.default_value = valeur
    return s


# ── rendu : carte graphique ───────────────────────────────────────────────────────────────────────────────
def carte_graphique(sc):
    prefs = bpy.context.preferences.addons['cycles'].preferences
    choisi = None
    for typ in ('OPTIX', 'CUDA'):
        try:
            prefs.compute_device_type = typ
            (prefs.refresh_devices if hasattr(prefs, 'refresh_devices') else prefs.get_devices)()
            gpus = [d for d in prefs.devices if d.type == typ]
            if gpus:
                for d in prefs.devices:
                    d.use = d.type == typ
                choisi = typ
                print('Carte graphique :', typ, [d.name for d in gpus])
                break
        except Exception as e:
            print('  pas de', typ, ':', str(e)[:100])
    sc.cycles.device = 'GPU' if choisi else 'CPU'
    return choisi or 'CPU'


def reglages(sc, film, o, appareil):
    sc.render.engine = 'CYCLES'
    sc.cycles.samples = int(o['echantillons'])
    essai(setattr, sc.cycles, 'use_adaptive_sampling', True)
    essai(setattr, sc.cycles, 'adaptive_threshold', 0.03)
    sc.cycles.use_denoising = True
    essai(setattr, sc.cycles, 'denoiser', 'OPTIX' if appareil == 'OPTIX' else 'OPENIMAGEDENOISE')
    essai(setattr, sc.cycles, 'denoising_use_gpu', True)
    for k, v in (('max_bounces', 6), ('diffuse_bounces', 3), ('glossy_bounces', 3), ('transmission_bounces', 2),
                 ('transparent_max_bounces', 10), ('volume_bounces', 0), ('caustics_reflective', False),
                 ('caustics_refractive', False), ('blur_glossy', 1.0)):
        essai(setattr, sc.cycles, k, v)
    sc.render.use_persistent_data = True
    sc.render.resolution_x = int(film['largeur'])
    sc.render.resolution_y = int(film['hauteur'])
    sc.render.resolution_percentage = int(o['pourcent'])
    sc.render.fps = int(film.get('ips', 25))
    sc.render.image_settings.file_format = 'PNG'
    sc.render.image_settings.color_mode = 'RGB'
    sc.render.use_motion_blur = True
    essai(setattr, sc.render, 'motion_blur_shutter', 0.5)
    essai(setattr, sc.view_settings, 'view_transform', 'AgX')
    essai(setattr, sc.view_settings, 'look', 'AgX - Medium High Contrast')
    bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'


# ── maillages ─────────────────────────────────────────────────────────────────────────────────────────────
def creer_maillage(nom, P, I, UV=None, couleurs=None, normales=None, extra=None):
    """P : points (repère du site), placés tels quels ; l'objet porte la conversion vers Blender (FS.C4)."""
    me = bpy.data.meshes.new(nom)
    P = np.asarray(P, dtype=np.float64)
    me.from_pydata(P.tolist(), [], np.asarray(I, dtype=np.int64).tolist())
    boucles = np.asarray(I, dtype=np.int64).ravel()
    if UV is not None:
        uv = np.asarray(UV, dtype=np.float64)[boucles].copy()
        uv[:, 1] = 1.0 - uv[:, 1]                                    # WebGL : v vers le bas de l'image ; Blender : vers le haut
        me.uv_layers.new(name='UV').data.foreach_set('uv', uv.astype(np.float32).ravel())
    c = FS.lineaire(couleurs) if couleurs is not None else np.ones((len(P), 3))   # sans couleurs : blanc (le shader du site aussi)
    rgba = np.c_[c, np.ones(len(c))].astype(np.float32)
    me.color_attributes.new(name='Col', type='FLOAT_COLOR', domain='POINT').data.foreach_set('color', rgba.ravel())
    for nom_a, (typ, val) in (extra or {}).items():
        a = me.attributes.new(name=nom_a, type=typ, domain='POINT')
        a.data.foreach_set('vector' if typ == 'FLOAT_VECTOR' else 'value', np.asarray(val, dtype=np.float32).ravel())
    me.polygons.foreach_set('use_smooth', [True] * len(me.polygons))
    if normales is not None:
        essai(me.normals_split_custom_set_from_vertices, np.asarray(normales, dtype=np.float64).tolist())
    me.update()
    return me


def objet(nom, me, mat=None):
    ob = bpy.data.objects.new(nom, me)
    bpy.context.scene.collection.objects.link(ob)
    ob.matrix_world = FS.C4.tolist()
    if mat is not None:
        me.materials.append(mat)
    return ob


# ── matières ──────────────────────────────────────────────────────────────────────────────────────────────
class ND:
    """Moteur « nœuds » de la règle des tenues (film_scene.classe_tenue) : chaque opération devient un nœud Math ;
    les constantes sont calculées tout de suite."""
    def __init__(self, nt):
        self.nt = nt

    def c(self, v): return float(v)

    def _m(self, op, *xs):
        if all(isinstance(x, float) for x in xs):
            a = xs
            return float({'ADD': lambda: a[0] + a[1], 'SUBTRACT': lambda: a[0] - a[1], 'MULTIPLY': lambda: a[0] * a[1],
                          'GREATER_THAN': lambda: 1.0 if a[0] > a[1] else 0.0, 'LESS_THAN': lambda: 1.0 if a[0] < a[1] else 0.0,
                          'ABSOLUTE': lambda: abs(a[0]), 'MAXIMUM': lambda: max(a), 'FLOOR': lambda: math.floor(a[0]),
                          'SQRT': lambda: math.sqrt(max(a[0], 0))}[op]())
        n = self.nt.nodes.new('ShaderNodeMath')
        n.operation = op
        for i, x in enumerate(xs):
            if isinstance(x, float):
                n.inputs[i].default_value = x
            else:
                self.nt.links.new(x, n.inputs[i])
        return n.outputs[0]

    def add(self, a, b): return self._m('ADD', a, b)
    def sub(self, a, b): return self._m('SUBTRACT', a, b)
    def mul(self, a, b): return self._m('MULTIPLY', a, b)
    def gt(self, a, b): return self._m('GREATER_THAN', a, b)
    def lt(self, a, b): return self._m('LESS_THAN', a, b)
    def abs(self, a): return self._m('ABSOLUTE', a)
    def max(self, a, b): return self._m('MAXIMUM', a, b)
    def floor(self, a): return self._m('FLOOR', a)
    def sqrt(self, a): return self._m('SQRT', a)
    def sel(self, c, a, b): return self.add(b, self.mul(self.sub(a, b), c))

    def vec(self, v):
        n = self.nt.nodes.new('ShaderNodeCombineXYZ')
        for i in range(3):
            n.inputs[i].default_value = float(v[i])
        return n.outputs[0]

    def vop(self, op, a, b=None, s=None):
        n = self.nt.nodes.new('ShaderNodeVectorMath')
        n.operation = op
        for i, x in enumerate([a, b]):
            if x is None:
                continue
            if isinstance(x, (tuple, list)):
                n.inputs[i].default_value = tuple(float(v) for v in x[:3])
            else:
                self.nt.links.new(x, n.inputs[i])
        if s is not None:
            if isinstance(s, float):
                n.inputs['Scale'].default_value = s
            else:
                self.nt.links.new(s, n.inputs['Scale'])
        return n.outputs[0]


def matiere_base(nom):
    m = bpy.data.materials.new(nom)
    m.use_nodes = True
    nt = m.node_tree
    bsdf = nt.nodes.get('Principled BSDF')
    return m, nt, bsdf


def attribut(nt, nom, sortie='Color'):
    n = nt.nodes.new('ShaderNodeAttribute')
    n.attribute_name = nom
    return n.outputs[sortie]


def image_tex(nt, img, repeter=True):
    n = nt.nodes.new('ShaderNodeTexImage')
    n.image = img
    n.interpolation = 'Linear'
    n.extension = 'REPEAT' if repeter else 'EXTEND'
    return n


def rugosite(spec):
    return float(min(0.92, max(0.18, 0.86 - spec * 1.3)))


class Matieres:
    def __init__(self, film, dossier_tex):
        self.film, self.cache, self.images = film, {}, {}
        os.makedirs(dossier_tex, exist_ok=True)
        for k, t in film['textures'].items():
            ch = os.path.join(dossier_tex, f'tex_{k}.png')
            with open(ch, 'wb') as f:
                f.write(base64.b64decode(t['png']))
            img = bpy.data.images.load(ch)
            img.alpha_mode = 'STRAIGHT'
            self.images[int(k)] = (img, bool(t['repeter']))
        self.sol = film['scene']['surface']
        self.reflet = float(film['scene'].get('reflet') or 0)

    def generique(self, o, cle=None, couleur=None, emis_k=1.0, mapping=False):
        """Comme le shader du site : couleur des sommets × couleur de l'objet × texture ; alpha ; émission."""
        cle = cle or json.dumps([o.get('m'), o.get('tex'), o.get('col'), o.get('alpha'), o.get('spec'), o.get('emis'), couleur, emis_k, mapping])
        if cle in self.cache:
            return self.cache[cle]
        m, nt, bsdf = matiere_base('m%d' % len(self.cache))
        B = ND(nt)
        coul = attribut(nt, 'Col')
        col = couleur if couleur is not None else o.get('col')
        if col is not None:
            coul = B.vop('MULTIPLY', coul, tuple(FS.lineaire(col)))
        alpha = float(o.get('alpha') or 1)
        a_sock = None
        if o.get('tex') and int(o['tex']) in self.images:
            img, rep = self.images[int(o['tex'])]
            tx = image_tex(nt, img, rep)
            if mapping:
                mp = nt.nodes.new('ShaderNodeMapping')
                uvn = nt.nodes.new('ShaderNodeUVMap')
                nt.links.new(uvn.outputs[0], mp.inputs['Vector'])
                nt.links.new(mp.outputs[0], tx.inputs['Vector'])
                m['mapping'] = mp.name
            coul = B.vop('MULTIPLY', coul, tx.outputs['Color'])
            a_sock = tx.outputs['Alpha']
            if alpha < 1:
                a_sock = B.mul(a_sock, alpha)
        nt.links.new(coul, bsdf.inputs['Base Color'])
        regler(bsdf, rugosite(float(o.get('spec') or 0.2)), 'Roughness')
        if a_sock is not None:
            nt.links.new(a_sock, bsdf.inputs['Alpha'])
        elif alpha < 1:
            regler(bsdf, alpha, 'Alpha')
        e = float(o.get('emis') or 0) * emis_k
        if e > 0:
            s = entree(bsdf, 'Emission Color', 'Emission')
            if s is not None:
                nt.links.new(coul, s)
            regler(bsdf, e, 'Emission Strength')
        self.cache[cle] = m
        return m

    def sol_court(self, o):
        m = self.generique(o, cle='sol')
        bsdf = m.node_tree.nodes.get('Principled BSDF')
        if self.sol in ('Hard', 'Carpet'):
            regler(bsdf, 0.5, 'Roughness')
            regler(bsdf, 0.45 if self.reflet else 0.25, 'Coat Weight', 'Clearcoat')
            regler(bsdf, 0.06, 'Coat Roughness', 'Clearcoat Roughness')
        elif self.sol == 'Clay':
            regler(bsdf, 0.95, 'Roughness')
        else:
            regler(bsdf, 0.82, 'Roughness')
            regler(bsdf, 0.3, 'Sheen Weight', 'Sheen')
        return m

    def public(self, o):
        """Panneaux du public : texture (8 silhouettes), maillot teinté par la couleur de chaque spectateur, découpe."""
        if 'public' in self.cache:
            return self.cache['public']
        m, nt, bsdf = matiere_base('public')
        B = ND(nt)
        img, rep = self.images[int(o['tex'])]
        tx = image_tex(nt, img, False)
        uvn = nt.nodes.new('ShaderNodeUVMap')
        sep = nt.nodes.new('ShaderNodeSeparateXYZ')
        nt.links.new(uvn.outputs[0], sep.inputs[0])
        v_site = B.sub(1.0, sep.outputs[1])
        haut = B.gt(v_site, 0.46)
        teinte = B.vop('MULTIPLY', tx.outputs['Color'], attribut(nt, 'Col'))
        teinte = B.vop('SCALE', teinte, s=float(1.25 ** 2.2))
        diff = B.vop('SUBTRACT', teinte, tx.outputs['Color'])
        coul = B.vop('ADD', tx.outputs['Color'], B.vop('SCALE', diff, s=haut))
        nt.links.new(coul, bsdf.inputs['Base Color'])
        nt.links.new(B.gt(tx.outputs['Alpha'], 0.5), bsdf.inputs['Alpha'])
        regler(bsdf, 0.85, 'Roughness')
        self.cache['public'] = m
        return m

    def corps(self, tex, tenue):
        """Corps des personnages : peau (texture) et tenue (couleurs du site), même règle que le shader du site."""
        cle = json.dumps(['corps', tex, tenue])
        if cle in self.cache:
            return self.cache[cle]
        m, nt, bsdf = matiere_base('corps%d' % len(self.cache))
        B = ND(nt)
        rep = nt.nodes.new('ShaderNodeAttribute')
        rep.attribute_name = 'repos'
        sep = nt.nodes.new('ShaderNodeSeparateXYZ')
        nt.links.new(rep.outputs['Vector'], sep.inputs[0])
        cls = attribut(nt, 'cls', 'Fac')
        T = tenue
        k = FS.classe_tenue(B, sep.outputs[0], sep.outputs[1], sep.outputs[2], cls, float(T[0][0]), float(T[0][1]))
        sans_bandeau = T[7][0] < 0
        peau = nt.nodes.new('ShaderNodeTexImage')
        if tex and int(tex) in self.images:
            peau.image = self.images[int(tex)][0]
        tissu = B.gt(k, 0.5)
        if sans_bandeau:
            tissu = B.mul(tissu, FS.non(B, FS.egal(B, k, 7)))
        coul = B.vop('SCALE', peau.outputs['Color'], s=FS.non(B, tissu))
        for K in range(1, 8):
            if K == 7 and sans_bandeau:
                continue
            coul = B.vop('ADD', coul, B.vop('SCALE', tuple(FS.lineaire(T[K])), s=FS.egal(B, k, K)))
        nt.links.new(coul, bsdf.inputs['Base Color'])
        nt.links.new(B.sel(tissu, 0.78, 0.48), entree(bsdf, 'Roughness'))
        s = entree(bsdf, 'Sheen Weight', 'Sheen')
        if s is not None:
            nt.links.new(B.mul(tissu, 0.35), s)
        s = entree(bsdf, 'Subsurface Weight', 'Subsurface')
        if s is not None:
            nt.links.new(B.mul(FS.non(B, tissu), 0.12), s)
            regler(bsdf, (0.012, 0.005, 0.003), 'Subsurface Radius')
        self.cache[cle] = m
        return m

    def personnage(self, mid, e):
        if e.get('tenue'):
            return self.corps(e.get('tex'), e['tenue'])
        return self.generique({'m': mid, 'tex': e.get('tex'), 'col': e.get('col'), 'spec': 0.1})


# ── lumières ──────────────────────────────────────────────────────────────────────────────────────────────
def lumiere_monde(sc, film):
    A = film['scene']['ambiance']
    w = bpy.data.worlds.new('Monde')
    sc.world = w
    w.use_nodes = True
    bg = w.node_tree.nodes.get('Background')
    c = FS.lineaire(A['ciel'])
    bg.inputs[0].default_value = (c[0], c[1], c[2], 1)
    bg.inputs[1].default_value = 0.9 if film['scene']['jour'] else 0.35


def regarder(ob, cible_blender):
    d = np.asarray(cible_blender) - np.asarray(ob.location)
    import mathutils
    ob.rotation_euler = mathutils.Vector(d.tolist()).to_track_quat('-Z', 'Y').to_euler()


def eclairage(sc, film):
    if film['scene']['jour']:
        s = np.asarray(film['scene']['soleil'], dtype=np.float64)
        s = FS.vers_blender([s / np.linalg.norm(s)])[0]
        L = bpy.data.lights.new('Soleil', 'SUN')
        L.energy = 4.0
        essai(setattr, L, 'angle', math.radians(0.8))
        ob = bpy.data.objects.new('Soleil', L)
        sc.collection.objects.link(ob)
        ob.location = (s * 50).tolist()
        regarder(ob, [0, 0, 0])
        return
    # nuit / salle : quatre rampes de projecteurs au-dessus des tribunes, une lumière d'appoint au-dessus du filet
    for k, (sx, sz) in enumerate(((-1, -1), (1, -1), (-1, 1), (1, 1))):
        L = bpy.data.lights.new(f'Projecteur{k}', 'AREA')
        L.shape = 'RECTANGLE'
        L.size, L.size_y = 12.0, 4.0
        L.energy = 5200.0
        L.color = (1.0, 0.97, 0.92)
        ob = bpy.data.objects.new(L.name, L)
        sc.collection.objects.link(ob)
        ob.location = FS.vers_blender([[sx * 18.0, 24.0, sz * 22.0]])[0].tolist()
        regarder(ob, [0, 0, 0])
    L = bpy.data.lights.new('Appoint', 'AREA')
    L.size = 20.0
    L.energy = 1800.0
    ob = bpy.data.objects.new('Appoint', L)
    sc.collection.objects.link(ob)
    ob.location = (0, 0, 30)
    regarder(ob, [0, 0, 0])


# ── la scène ──────────────────────────────────────────────────────────────────────────────────────────────
class Scene:
    def __init__(self, film, o):
        self.film, self.o = film, o
        self.sc = bpy.context.scene
        self.M = Matieres(film, os.path.join(o['sortie'], '_tex'))
        self.maillages = {}
        self.pools = {}          # (mid, peau ?) → objets
        self.led = None

    def m(self, mid):
        if mid not in self.maillages:
            self.maillages[mid] = FS.maillage(self.film, mid)
        return self.maillages[mid]

    def fixe(self, o, nom, matiere=None):
        d = self.m(o['m']) if o else None
        if d is None or len(d['p']) == 0:
            return None
        me = creer_maillage(nom, d['p'], d['i'], d.get('u'), d.get('c'), d.get('n'))
        return objet(nom, me, matiere or self.M.generique(o, emis_k=4.0 if (o.get('emis') or 0) > 1.2 else 1.3))

    def decor(self):
        S = self.film['scene']
        for k, o in enumerate(S['fixes']):
            if o:
                self.fixe(o, f'fixe{k}', self.M.sol_court(o) if k == 0 else None)
        for k, o in enumerate(S['transp']):
            if o:
                self.fixe(o, f'transp{k}')
        for k, o in enumerate(S.get('arbitre') or []):
            if o:
                self.fixe(o, f'arbitre{k}')
        if S.get('led'):
            ob = self.fixe(S['led'], 'led', self.M.generique(S['led'], cle='led', emis_k=1.3, mapping=True))
            self.led = ob.active_material if ob else None
        if S.get('ecran'):
            self.fixe(S['ecran'], 'ecran', self.M.generique(S['ecran'], cle='ecran', emis_k=1.3))
        p = S.get('public')
        if p and self.m(p['m']) and self.m(p['m']).get('inst'):
            d = self.m(p['m'])
            pts, uv, cols = FS.public(d, d['inst'], [0, 1.5, 0], 0, 0, 0)
            I = FS.indices_public(d, len(d['inst']['pos']))
            me = creer_maillage('public', pts, I, uv, cols)
            self.public = objet('public', me, self.M.public(p))
            self.public_d = d
        else:
            self.public = None

    def pool(self, mid, peau, n):
        cle = (mid, peau)
        L = self.pools.setdefault(cle, [])
        d = self.m(mid)
        while len(L) < n and d is not None:
            nom = f"{'p' if peau else 'o'}{mid}_{len(L)}"
            extra = {}
            if peau:
                extra = {'repos': ('FLOAT_VECTOR', d['p']), 'cls': ('FLOAT', d['cls'].astype(np.float64) if 'cls' in d else np.zeros(len(d['p'])))}
            me = creer_maillage(nom, d['p'], d['i'], d.get('u'), d.get('c'), None if peau else d.get('n'), extra)
            ob = objet(nom, me)
            me.materials.append(None)
            if not peau:
                ob.rotation_mode = 'QUATERNION'
            essai(setattr, ob.cycles, 'use_deform_motion', False) if peau else None
            L.append(ob)
        return L

    def preparer(self, images):
        """Crée les objets mobiles et pose les clés d'animation des objets rigides (balle, raquettes, cordages) pour le
        flou de mouvement ; prépare toutes les matières."""
        import mathutils
        besoin = {}
        for im in images:
            compte = {}
            for e in im['dyn']:
                cle = (e['m'], e['os'] >= 0)
                compte[cle] = compte.get(cle, 0) + 1
            for c, n in compte.items():
                besoin[c] = max(besoin.get(c, 0), n)
        for (mid, peau), n in besoin.items():
            if mid:
                self.pool(mid, peau, n)
        for im in images:
            for e in im['dyn']:
                if e['m'] and e['os'] >= 0:
                    self.M.personnage(e['m'], e)
                elif e['m']:
                    tex = e.get('tex') or (self.film['scene'].get('cordage') if e['tr'] else 0)      # cordages : texture du site
                    self.M.generique({'m': e['m'], 'tex': tex, 'col': e.get('col'), 'spec': 0.35,
                                      'alpha': 0.8 if e['tr'] else 1}, cle=f"rigide{e['m']}")
        # balle
        bid = self.film['scene'].get('balle')
        self.balle = None
        if bid and self.m(bid):
            d = self.m(bid)
            me = creer_maillage('balle', d['p'], d['i'], d.get('u'), d.get('c'), d.get('n'))
            self.balle = objet('balle', me, self.M.generique({'m': bid, 'spec': 0.5, 'emis': 0.35}, cle='balle', emis_k=1.6))
        # clés : objets rigides et balle
        derniere = None
        for f, im in enumerate(images, start=1):
            occ = {}
            vus = set()
            for e in im['dyn']:
                if not e['m'] or e['os'] >= 0:
                    continue
                cle = (e['m'], False)
                k = occ.get(cle, 0)
                occ[cle] = k + 1
                ob = self.pools[cle][k]
                vus.add(ob.name)
                M = mathutils.Matrix((FS.C4 @ FS.mat4(e['mat'])).tolist())
                loc, rot, sca = M.decompose()
                ob.location, ob.rotation_quaternion, ob.scale = loc, rot, sca
                ob.data.materials[0] = self.M.cache[f"rigide{e['m']}"]
                for ch in ('location', 'rotation_quaternion', 'scale'):
                    ob.keyframe_insert(ch, frame=f)
                ob.hide_render = False
                ob.keyframe_insert('hide_render', frame=f)
            for (mid, peau), L in self.pools.items():
                if peau:
                    continue
                for ob in L:
                    if ob.name not in vus:
                        ob.hide_render = True
                        ob.keyframe_insert('hide_render', frame=f)
            if self.balle is not None:
                b = im.get('balle') or derniere
                if b is not None:
                    derniere = b
                    self.balle.location = FS.vers_blender([b])[0].tolist()
                    self.balle.keyframe_insert('location', frame=f)
                self.balle.hide_render = im.get('balle') is None
                self.balle.keyframe_insert('hide_render', frame=f)
        for ob in list(bpy.data.objects):
            ad = ob.animation_data
            if ad and ad.action:
                for fc in ad.action.fcurves:
                    for kp in fc.keyframe_points:
                        kp.interpolation = 'CONSTANT' if fc.data_path == 'hide_render' else 'LINEAR'

    def poser(self, f, im):
        """Image f : caméra, personnages déformés par leurs os, public tourné vers la caméra, panneaux LED."""
        import mathutils
        self.sc.frame_set(f)
        occ = {}
        utilises = set()
        for e in im['dyn']:
            if not e['m'] or e['os'] < 0:
                continue
            cle = (e['m'], True)
            k = occ.get(cle, 0)
            occ[cle] = k + 1
            ob = self.pools[cle][k]
            utilises.add(ob.name)
            d = self.m(e['m'])
            S = FS.os_image(self.film, e['os'])
            P = FS.deformer(d['p'], d['b'], d['w'], S)
            ob.data.vertices.foreach_set('co', P.astype(np.float32).ravel())
            if 'n' in d:
                essai(ob.data.normals_split_custom_set_from_vertices, FS.deformer_normales(d['n'], d['b'], d['w'], S).tolist())
            ob.data.update()
            ob.data.materials[0] = self.M.personnage(e['m'], e)
            ob.hide_render = False
        for (mid, peau), L in self.pools.items():
            if peau:
                for ob in L:
                    if ob.name not in utilises:
                        ob.hide_render = True
        # caméra
        cam = self.camera
        cam.matrix_world = mathutils.Matrix(FS.camera(im['eye'], im['cible']).tolist())
        cam.data.angle_y = float(im['fov'])
        foc = float(im.get('foc') or 0)
        cam.data.dof.use_dof = foc > 0
        if foc > 0:
            cam.data.dof.focus_distance = foc
            cam.data.dof.aperture_fstop = 1.8 if foc < 7 else 2.8
        # public
        if self.public is not None:
            d = self.public_d
            pts, _, _ = FS.public(d, d['inst'], im['eye'], im.get('tr') or im['t'], im.get('clap') or 0, im.get('debout') or 0)
            self.public.data.vertices.foreach_set('co', pts.astype(np.float32).ravel())
            self.public.data.update()
        if self.led is not None and self.led.get('mapping'):
            mp = self.led.node_tree.nodes.get(self.led['mapping'])
            if mp is not None:
                mp.inputs['Location'].default_value[0] = float(im.get('led') or 0)

    def construire(self, images):
        self.decor()
        cd = bpy.data.cameras.new('Camera')
        cd.sensor_fit = 'VERTICAL'
        cd.sensor_height = 24.0
        cd.clip_start, cd.clip_end = 0.3, 300.0
        self.camera = bpy.data.objects.new('Camera', cd)
        self.sc.collection.objects.link(self.camera)
        self.sc.camera = self.camera
        lumiere_monde(self.sc, self.film)
        eclairage(self.sc, self.film)
        self.preparer(images)
        self.sc.frame_start, self.sc.frame_end = 1, len(images)


def exposition_auto(scn, images, sortie):
    """Petite image d'essai de la première image (25 %, 8 échantillons, valeurs linéaires) : l'exposition est réglée
    pour que la médiane de la zone centrale vaille 0,2 (court bien éclairé, comme sur le site)."""
    sc = scn.sc
    garde = (sc.render.resolution_percentage, sc.cycles.samples, sc.render.image_settings.file_format,
             sc.render.image_settings.color_mode, sc.render.use_motion_blur)
    sc.render.resolution_percentage = 25
    sc.cycles.samples = 8
    sc.render.image_settings.file_format = 'OPEN_EXR'
    sc.render.image_settings.color_mode = 'RGB'
    sc.render.use_motion_blur = False
    sc.view_settings.exposure = 0
    scn.poser(1, images[0])
    ch = os.path.join(sortie, '_expo.exr')
    sc.render.filepath = ch
    bpy.ops.render.render(write_still=True)
    img = bpy.data.images.load(ch)
    w, h = img.size
    px = np.empty(w * h * 4, dtype=np.float32)
    img.pixels.foreach_get(px)
    px = px.reshape(h, w, 4)
    zone = px[int(h * 0.2):int(h * 0.8), int(w * 0.1):int(w * 0.9), :3]
    lum = 0.2126 * zone[..., 0] + 0.7152 * zone[..., 1] + 0.0722 * zone[..., 2]
    med = float(np.median(lum))
    expo = float(np.clip(math.log2(0.2 / max(med, 1e-5)), -8, 8))
    (sc.render.resolution_percentage, sc.cycles.samples, sc.render.image_settings.file_format,
     sc.render.image_settings.color_mode, sc.render.use_motion_blur) = garde
    sc.view_settings.exposure = expo
    print(f'Exposition : médiane {med:.4f} → {expo:+.2f} IL')
    return med, expo


def main():
    o = options()
    t_debut = time.time()
    os.makedirs(o['sortie'], exist_ok=True)
    film = FS.lire(o['entree'])
    images = film['images'][:int(o['max-images'])]
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    appareil = carte_graphique(sc)
    reglages(sc, film, o, appareil)
    scn = Scene(film, o)
    scn.construire(images)
    temps = {'paquet': 299, 'blender': bpy.app.version_string, 'appareil': appareil, 'echantillons': int(o['echantillons']), 'ips': int(film.get('ips', 25)),
             'resolution': f"{sc.render.resolution_x}x{sc.render.resolution_y}@{sc.render.resolution_percentage}%",
             'images_point': len(images), 'preparation_s': round(time.time() - t_debut, 1), 'rendus': []}
    if o['exposition'] == 'auto':
        med, expo = exposition_auto(scn, images, o['sortie'])
        temps['exposition'] = round(expo, 2)
    else:
        sc.view_settings.exposure = float(o['exposition'])
    if o['images'] == 'tout':
        a_faire = list(range(len(images)))
    else:
        a_faire = sorted({min(len(images) - 1, max(0, int(x))) for x in o['images'].split(',') if x.strip()})
    for k in a_faire:
        t = time.time()
        scn.poser(k + 1, images[k])
        sc.render.filepath = os.path.join(o['sortie'], f'img_{k:04d}.png')
        bpy.ops.render.render(write_still=True)
        temps['rendus'].append({'image': k, 's': round(time.time() - t, 2)})
        if len(temps['rendus']) % 10 == 1 or k == a_faire[-1]:
            s = [r['s'] for r in temps['rendus']]
            temps['s_par_image'] = round(float(np.median(s)), 2)
            temps['total_s'] = round(time.time() - t_debut, 1)
            with open(os.path.join(o['sortie'], 'temps.json'), 'w', encoding='utf-8') as f:
                json.dump(temps, f, ensure_ascii=False, indent=1)
            print(f"image {k + 1}/{len(images)} : {temps['rendus'][-1]['s']} s (médiane {temps['s_par_image']} s)")
    print('Fini :', json.dumps({k: v for k, v in temps.items() if k != 'rendus'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
