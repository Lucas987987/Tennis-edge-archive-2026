#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
film_export.py — ESSAI (paquet 299, 19/11/2026, Lucas : « Si tout est gratuit et que l'on fait un vrai bond de
qualité, on y va ») : un point de la vidéo du jour, exporté du moteur 3D du site pour être rendu par Blender sur une
carte graphique louée (Modal), et le même point filmé par le site, pour comparer.

La page du film est ouverte avec ?export3d=1 : le moteur garde alors une copie de ses maillages et de ses textures, et
note à chaque image la caméra, la balle et la pose de chaque personnage (les matrices de ses 24 os). Les mouvements
restent donc EXACTEMENT ceux du site : seul le rendu change. Les textes de l'habillage télé sont masqués des deux
côtés (on compare l'image 3D seule).

Sortie (dossier --sortie) :
  film.json.gz   — scène, maillages, textures (PNG) et images du point (données pour scripts/blender_film.py)
  site_point.mp4 — le même point filmé par le site (référence) : la zone 3D seule, sans habillage
  export.json    — nombre d'images, temps de calcul (rien sur le match)

Usage : python scripts/film_export.py [--lang fr] [--uid UID] [--point 1] [--ips 25] [--max-s 14] [--sortie essai_gpu]
"""
import argparse
import base64
import gzip
import json
import os
import subprocess
import sys
import time
from collections import deque

ICI = os.path.dirname(os.path.abspath(__file__))
RACINE = os.path.join(ICI, '..')
sys.path.insert(0, ICI)

AVANT_S = 1.0          # secondes gardées avant le début du point (le serveur fait rebondir la balle)
APRES_S = 1.2          # secondes gardées après la fin du point
CACHE_HABILLAGE = '.film > :not(.f3-hote) { visibility: hidden !important; }'


def b64(tableau, type_np):
    import numpy as np
    return base64.b64encode(np.asarray(tableau, dtype=type_np).tobytes()).decode('ascii')


def encoder_maillage(d):
    """Maillage du moteur → tableaux binaires (base64) ; None si vide."""
    if not d or not d.get('p') or not d.get('i'):
        return None
    out = {'nv': len(d['p']) // 3, 'p': b64(d['p'], 'float32'), 'i': b64(d['i'], 'uint32')}
    for k, t in (('n', 'float32'), ('c', 'float32'), ('u', 'float32'), ('w', 'float32'), ('b', 'uint8'), ('cls', 'uint8')):
        if d.get(k):
            out[k] = b64(d[k], t)
    if d.get('inst'):
        out['inst'] = {'pos': b64(d['inst']['pos'], 'float32'), 'col': b64(d['inst']['col'], 'float32'),
                       'n': len(d['inst']['pos']) // 4}
    return out


def encoder_image(im, os_uniques):
    """Une image du film : les matrices d'os identiques (corps, yeux, cheveux d'un même personnage) ne sont gardées
    qu'une fois."""
    dyn = []
    for e in im['dyn']:
        k = -1
        if e.get('os'):
            cle = tuple(round(v, 6) for v in e['os'])
            k = os_uniques.setdefault(cle, len(os_uniques))
        dyn.append({'m': e['m'], 'mat': [round(v, 6) for v in e['mat']], 'tr': e['tr'], 'os': k, 'tex': e['tex'],
                    'tenue': e.get('tenue'), 'col': e.get('col')})
    r = {k: im[k] for k in ('t', 'tr', 'w', 'h', 'eye', 'cible', 'fov', 'foc', 'jour', 'surface', 'balle', 'led', 'ralenti', 'clap', 'debout')}
    r['dyn'] = dyn
    return r


def exporter(url, dossier, ips=25, point=1, max_s=14.0, taille=(1080, 1920), log=print):
    import video_simulation as VS
    from playwright.sync_api import sync_playwright
    os.makedirs(dossier, exist_ok=True)
    mp4 = os.path.join(dossier, 'site_point.mp4')
    pas = 1000.0 / ips
    anneau = deque(maxlen=max(1, int(round(AVANT_S * ips))))
    gardees, debut_rec, fin_rec = [], None, None
    t0 = time.time()
    with sync_playwright() as p:
        nav = p.chromium.launch(args=VS.NAV_ARGS)
        page = nav.new_page(viewport={'width': taille[0], 'height': taille[1]}, device_scale_factor=1)
        erreurs = []
        page.on('pageerror', lambda e: erreurs.append(str(e)[:200]))
        page.add_init_script(VS.HORLOGE)
        page.goto(url)
        limite = time.time() + 30
        while not page.evaluate('window.__sons !== undefined || window.__fini === true'):
            if time.time() > limite:
                raise RuntimeError('la page vidéo ne démarre pas')
            time.sleep(0.1)
        limite = time.time() + 120
        while not page.evaluate('window.__pret === true || window.__fini === true'):
            if time.time() > limite:
                raise RuntimeError('la vidéo 3D ne démarre pas')
            page.evaluate('ms => window.__horloge.avance(ms)', 50)
        if not page.evaluate('!!(window.__G3D && window.__G3D._export && window.__G3D._export.actif())'):
            raise RuntimeError('export inactif (page sans le paquet 299 ?)')
        page.add_style_tag(content=CACHE_HABILLAGE)
        x, y, w, h = page.evaluate('window.__G3D._export.scene().cadre')            # la zone 3D de la page (sans l'habillage)
        clip = {'x': round(x), 'y': round(y), 'width': int(w) // 2 * 2, 'height': int(h) // 2 * 2}
        etat_avant, vus, n = False, 0, 0
        while n < 400 * ips:                                       # 400 s de film au plus
            page.evaluate('ms => window.__horloge.avance(ms)', pas)
            n += 1
            e = page.evaluate('window.__G3D.film.etat()')
            im = page.evaluate('window.__G3D._export.image()')
            fini = page.evaluate('window.__fini === true')
            if im is None:
                continue
            jpg = page.screenshot(type='jpeg', quality=92, clip=clip)
            if debut_rec is None:
                if e['R'] and not etat_avant:
                    vus += 1
                    if vus == point:
                        debut_rec = n
                        gardees.extend(anneau)
                        anneau.clear()
                etat_avant = bool(e['R'])
                if debut_rec is None:
                    anneau.append((im, jpg))
                    if fini:
                        break
                    continue
            gardees.append((im, jpg))
            if fin_rec is None and not e['R'] and not e['ralenti']:
                fin_rec = n
            if (fin_rec is not None and n - fin_rec >= APRES_S * ips) or len(gardees) >= max_s * ips or fini:
                break
        if not gardees:
            raise RuntimeError(f'point {point} introuvable dans le film ({vus} points vus)')
        sc = page.evaluate('window.__G3D._export.scene()')
        ids = page.evaluate('window.__G3D._export.ids()')
        maillages = {}
        for i in ids:
            m = encoder_maillage(page.evaluate('id => window.__G3D._export.maillage(id)', i))
            if m:
                maillages[str(i)] = m
        textures = {}
        for i in page.evaluate('window.__G3D._export.textures()'):
            t = page.evaluate('id => window.__G3D._export.texture(id)', i)
            if t:
                textures[str(i)] = {'png': t['png'].split(',', 1)[1], 'repeter': t['repeter'], 'w': t['w'], 'h': t['h']}
        nav.close()
    os_uniques = {}
    images = [encoder_image(im, os_uniques) for im, _ in gardees]
    os_tab = [None] * len(os_uniques)
    for cle, k in os_uniques.items():
        os_tab[k] = b64(cle, 'float32')
    film = {'version': 1, 'paquet': 299, 'ips': ips, 'largeur': clip['width'], 'hauteur': clip['height'], 'scene': sc,
            'maillages': maillages, 'textures': textures, 'os': os_tab, 'images': images}
    with gzip.open(os.path.join(dossier, 'film.json.gz'), 'wt', encoding='utf-8', compresslevel=6) as f:
        json.dump(film, f, separators=(',', ':'))
    ff = subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', str(ips), '-c:v', 'mjpeg', '-i', '-',
                         '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-an', mp4],
                        input=b''.join(j for _, j in gardees))
    if ff.returncode:
        raise RuntimeError('ffmpeg : vidéo du site non faite')
    resume = {'paquet': 299, 'images': len(images), 'ips': ips, 'secondes': round(len(images) / ips, 2), 'point': point,
              'maillages': len(maillages), 'textures': len(textures), 'poses_uniques': len(os_tab),
              'calcul_s': round(time.time() - t0, 1), 'film_mo': round(os.path.getsize(os.path.join(dossier, 'film.json.gz')) / 1e6, 2),
              'erreurs_page': erreurs[:3]}
    with open(os.path.join(dossier, 'export.json'), 'w', encoding='utf-8') as f:
        json.dump(resume, f, ensure_ascii=False, indent=1)
    log(f"Export : {resume['images']} images ({resume['secondes']} s), {resume['maillages']} maillages, "
        f"{resume['textures']} textures, {resume['film_mo']} Mo, {resume['calcul_s']} s de calcul")
    return resume


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--lang', default='fr', choices=['fr', 'en'])
    ap.add_argument('--uid', default='')
    ap.add_argument('--point', type=int, default=1, help='quel point du film (1 = le premier joué)')
    ap.add_argument('--ips', type=int, default=25)
    ap.add_argument('--max-s', type=float, default=14.0)
    ap.add_argument('--sortie', default='essai_gpu')
    a = ap.parse_args(argv[1:])
    import video_simulation as VS
    algo = os.path.join(RACINE, 'algo')
    if not os.path.exists(os.path.join(algo, 'donnees.json')):
        print("algo/donnees.json absent.")
        return 1
    srv = VS.servir(algo)
    try:
        url = (f"http://127.0.0.1:{srv.server_address[1]}/index.html?video=1&rendu=3d&export3d=1&lang={a.lang}"
               + (f"&uid={a.uid}" if a.uid else ''))
        exporter(url, a.sortie, ips=a.ips, point=max(1, a.point), max_s=a.max_s)
    finally:
        srv.shutdown()
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
