# -*- coding: utf-8 -*-
"""
modal_rendu.py — ESSAI (paquet 299) : rendre le point exporté (scripts/film_export.py) avec Blender sur une carte
graphique louée chez Modal (facturée à la seconde, rien quand rien ne tourne ; crédits gratuits chaque mois).

Lancé par le workflow « Essai — rendu Blender sur carte graphique » (à la main seulement) :
  modal run scripts/modal_rendu.py --entree essai_gpu/film.json.gz --sortie essai_gpu [--gpu L4] [--echantillons 64]
                                   [--images tout|0,50,99]
Les jetons MODAL_TOKEN_ID / MODAL_TOKEN_SECRET viennent des secrets du dépôt (variables d'environnement du job) : ils
ne sont jamais écrits ni affichés.

Garde-fous de coût : 45 min au plus par appel (arrêt forcé par Modal), 400 images au plus, 2 processeurs et 6 Go de
mémoire (le prix d'une minute reste celui de la carte graphique, à quelques centimes près). Une seule machine à la
fois. Rien ne tourne en dehors de ce lancement manuel.
"""
import json
import os
import subprocess
import sys
import tempfile
import time

import modal

ICI = os.path.dirname(os.path.abspath(__file__))
BLENDER = '4.2.3'                                   # série LTS 4.2 (déjà téléchargée par l'essai Blender du paquet 278)
DUREE_MAX_S = 45 * 60
IMAGES_MAX = 400
# prix de Modal à l'heure (carte graphique), relevés le 19/11/2026 sur modal.com/pricing ; + ~0,14 $/h (2 processeurs,
# 6 Go de mémoire)
PRIX_HEURE = {'T4': 0.59, 'L4': 0.80, 'A10G': 1.10}
PRIX_CPU_MEMOIRE_HEURE = 0.14

image = (
    modal.Image.debian_slim(python_version='3.11')
    .apt_install('curl', 'xz-utils', 'ffmpeg', 'libx11-6', 'libxi6', 'libxxf86vm1', 'libxfixes3', 'libxrender1', 'libxext6',
                 'libgl1', 'libegl1', 'libsm6', 'libice6', 'libxkbcommon0', 'libglib2.0-0', 'libfontconfig1')
    .run_commands(
        f'curl -fsSL --retry 3 -o /tmp/blender.tar.xz https://download.blender.org/release/Blender4.2/blender-{BLENDER}-linux-x64.tar.xz',
        'mkdir -p /opt/blender && tar -xJf /tmp/blender.tar.xz -C /opt/blender --strip-components=1 && rm /tmp/blender.tar.xz',
        '/opt/blender/blender -b --factory-startup --version | head -1',
    )
    .add_local_file(os.path.join(ICI, 'blender_film.py'), '/root/rendu/blender_film.py')
    .add_local_file(os.path.join(ICI, 'film_scene.py'), '/root/rendu/film_scene.py')
)

app = modal.App('tennis-edge-essai-gpu', image=image)


@app.function(gpu='L4', cpu=2.0, memory=6144, timeout=DUREE_MAX_S, max_containers=1)
def rendre(film_gz: bytes, echantillons: int = 64, images: str = 'tout') -> dict:
    t0 = time.time()
    dossier = tempfile.mkdtemp()
    entree = os.path.join(dossier, 'film.json.gz')
    with open(entree, 'wb') as f:
        f.write(film_gz)
    sortie = os.path.join(dossier, 'images')
    gpu = subprocess.run(['nvidia-smi', '--query-gpu=name,memory.total,driver_version', '--format=csv,noheader'],
                         capture_output=True, text=True).stdout.strip()
    cmd = ['/opt/blender/blender', '-b', '--factory-startup', '-P', '/root/rendu/blender_film.py', '--',
           '--entree', entree, '--sortie', sortie, '--echantillons', str(int(echantillons)), '--images', images,
           '--max-images', str(IMAGES_MAX)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=DUREE_MAX_S - 120)
    journal = (r.stdout + '\n' + r.stderr)[-6000:]
    temps = {}
    ch = os.path.join(sortie, 'temps.json')
    if os.path.exists(ch):
        with open(ch, encoding='utf-8') as f:
            temps = json.load(f)
    pngs = sorted(x for x in os.listdir(sortie) if x.startswith('img_') and x.endswith('.png')) if os.path.isdir(sortie) else []
    out = {'code': r.returncode, 'journal': journal, 'temps': temps, 'carte': gpu, 'mp4': None, 'apercus': {}}
    if pngs:
        n = len(pngs)
        for k in sorted({0, n // 2, n - 1}):
            with open(os.path.join(sortie, pngs[k]), 'rb') as f:
                out['apercus'][pngs[k]] = f.read()
    if len(pngs) > 3:
        mp4 = os.path.join(dossier, 'blender_point.mp4')
        ff = subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-framerate', str(temps.get('ips', 25) if isinstance(temps, dict) else 25),
                             '-pattern_type', 'glob', '-i', os.path.join(sortie, 'img_*.png'), '-c:v', 'libx264', '-preset', 'medium',
                             '-crf', '17', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', mp4], capture_output=True, text=True)
        if ff.returncode == 0:
            with open(mp4, 'rb') as f:
                out['mp4'] = f.read()
        else:
            out['journal'] += '\nffmpeg : ' + ff.stderr[-500:]
    out['machine_s'] = round(time.time() - t0, 1)
    return out


@app.local_entrypoint()
def main(entree: str = 'essai_gpu/film.json.gz', sortie: str = 'essai_gpu', gpu: str = 'L4', echantillons: int = 64,
         images: str = 'tout'):
    gpu = gpu if gpu in PRIX_HEURE else 'L4'
    with open(entree, 'rb') as f:
        donnees = f.read()
    fonction = rendre.with_options(gpu=gpu) if gpu != 'L4' else rendre
    t0 = time.time()
    r = fonction.remote(donnees, echantillons, images)
    os.makedirs(sortie, exist_ok=True)
    if r.get('mp4'):
        with open(os.path.join(sortie, 'blender_point.mp4'), 'wb') as f:
            f.write(r['mp4'])
    for nom, octets in (r.get('apercus') or {}).items():
        with open(os.path.join(sortie, 'blender_' + nom), 'wb') as f:
            f.write(octets)
    machine_h = (r.get('machine_s') or (time.time() - t0)) / 3600
    resume = {'paquet': 299, 'gpu': gpu, 'carte': r.get('carte'), 'code_blender': r.get('code'),
              'machine_s': r.get('machine_s'), 'cout_essai_dollars': round(machine_h * (PRIX_HEURE[gpu] + PRIX_CPU_MEMOIRE_HEURE), 3),
              'prix_heure': PRIX_HEURE[gpu] + PRIX_CPU_MEMOIRE_HEURE, **{k: v for k, v in (r.get('temps') or {}).items() if k != 'rendus'}}
    with open(os.path.join(sortie, 'rendu.json'), 'w', encoding='utf-8') as f:
        json.dump(resume, f, ensure_ascii=False, indent=1)
    with open(os.path.join(sortie, 'blender_journal.txt'), 'w', encoding='utf-8') as f:
        f.write(r.get('journal') or '')
    print(json.dumps(resume, ensure_ascii=False))
    if not r.get('mp4') and images == 'tout':
        print(r.get('journal', '')[-3000:])
        sys.exit(1)
